//
//  AppDelegate.h
//  TokenTextFeild
//
//  Created by Halcyon on 5/6/16.
//  Copyright © 2016 Halcyon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

