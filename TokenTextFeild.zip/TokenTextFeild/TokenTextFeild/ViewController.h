//
//  ViewController.h
//  TokenTextFeild
//
//  Created by Halcyon on 5/6/16.
//  Copyright © 2016 Halcyon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CLTokenInputView.h"
#import "CLToken.h"
#import <QuartzCore/QuartzCore.h>

@interface ViewController : UIViewController<CLTokenInputViewDelegate>{
    
    CGFloat keyBoardHeight;
    
}


@property (strong, nonatomic) NSArray *names;

@property (nonatomic, strong) NSMutableArray *selectedNames;

@property (strong, nonatomic) IBOutlet CLTokenInputView *tokenInputView;
@property (nonatomic, strong) IBOutlet UIView *PopUpViewBackGround;
@property (nonatomic, strong) IBOutlet UIView *PopUpView;
@property (nonatomic, strong) IBOutlet UILabel *PopUpViewTitle;
@property (nonatomic, strong) IBOutlet UIScrollView *popUpScrollView;

-(IBAction)btnPopUpCancelClicked:(id)sender;
-(IBAction)btnPopUpDoneClicked:(id)sender;
-(IBAction)btnShowPopUpClicked:(id)sender;


@end

