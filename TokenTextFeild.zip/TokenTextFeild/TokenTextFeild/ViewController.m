//
//  ViewController.m
//  TokenTextFeild
//
//  Created by Halcyon on 5/6/16.
//  Copyright © 2016 Halcyon. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.navigationItem.title = @"Token Input Test";
        self.names = @[@"Brenden Mulligan",
                       @"Cluster Labs, Inc.",
                       @"Pat Fives",
                       @"Rizwan Sattar",
                       @"Taylor Hughes"];
        self.selectedNames = [NSMutableArray arrayWithCapacity:self.names.count];
        
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    
    self.tokenInputView.fieldName = @"To:";
   // self.tokenInputView.fieldView = infoButton;
    self.tokenInputView.placeholderText = @"Enter a name";
    //self.tokenInputView.accessoryView = [self contactAddButton];
    self.tokenInputView.drawBottomBorder = YES;
    _PopUpViewBackGround.hidden=YES;

    _PopUpView.layer.cornerRadius = 5;
    _PopUpView.layer.masksToBounds = YES;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification
                                               object:nil];

}





- (void)keyboardWasShown:(NSNotification *)notification
{
    
    // Get the size of the keyboard.
    CGSize keyboardSize = [[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    keyBoardHeight=keyboardSize.height;
    [self scrollEnableMethod];
//    //Given size may not account for screen rotation
//    int height = MIN(keyboardSize.height,keyboardSize.width);
//    int width = MAX(keyboardSize.height,keyboardSize.width);
    
    //your other code here..........
}
- (void) dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
   
}
- (void)viewDidAppear:(BOOL)animated
{
        [super viewDidAppear:animated];
}

-(IBAction)btnPopUpCancelClicked:(id)sender{
    [self ClosePopUp];
    
}
-(IBAction)btnPopUpDoneClicked:(id)sender{
    [self ClosePopUp];
}

-(void)ClosePopUp{
    _PopUpViewBackGround.hidden=YES;
    [_tokenInputView removeAllTokens];
    [self.tokenInputView endEditing];
 
}

-(IBAction)btnShowPopUpClicked:(id)sender{
    _PopUpViewBackGround.hidden=NO;
    //[self.tokenInputView beginEditing];
    [self scrollEnableMethod];

    if (!self.tokenInputView.editing) {
        [self.tokenInputView beginEditing];
    }


}
#pragma mark - CLTokenInputViewDelegate

- (void)tokenInputView:(CLTokenInputView *)view didChangeText:(NSString *)text
{

    if ([text hasSuffix:@" "]||[text hasSuffix:@","]) {
        
        NSString *name = view.text;
        name=[name stringByReplacingOccurrencesOfString:@" " withString:@""];
        name=[name stringByReplacingOccurrencesOfString:@"," withString:@""];
        CLToken *token = [[CLToken alloc] initWithDisplayText:name context:nil];
        if (self.tokenInputView.isEditing) {
            [self.tokenInputView addToken:token];
        }
    }
}
- (void)tokenInputView:(CLTokenInputView *)view didAddToken:(CLToken *)token
{
    NSString *name = token.displayText;
    [self.selectedNames addObject:name];
}

- (void)tokenInputView:(CLTokenInputView *)view didRemoveToken:(CLToken *)token
{
    NSString *name = token.displayText;
    [self.selectedNames removeObject:name];
}


- (void)tokenInputView:(CLTokenInputView *)view didChangeHeightTo:(CGFloat)height{
    
    NSLog(@"%f",height);
    _PopUpView.frame=CGRectMake(_PopUpView.frame.origin.x, _PopUpView.frame.origin.y, _PopUpView.frame.size.width,height+120);
    [self scrollEnableMethod];
    
}

-(void)scrollEnableMethod{
    
    CGFloat popUpViewhight=_PopUpView.frame.size.height;
    CGFloat constantHeight=_PopUpView.frame.origin.y+keyBoardHeight;
    CGFloat popUpDisplayHight=_popUpScrollView.frame.size.height-constantHeight;
    if (popUpDisplayHight < popUpViewhight) {
        _popUpScrollView.scrollEnabled=YES;
        [_popUpScrollView setContentSize:(CGSizeMake(self.view.frame.size.width,_popUpScrollView.frame.size.height+(popUpViewhight-popUpDisplayHight) ))];
    }else{
        [_popUpScrollView setContentSize:(CGSizeMake(self.view.frame.size.width,_popUpScrollView.frame.size.height))];
        _popUpScrollView.scrollEnabled=NO;
    }
    
    
    
}

- (CLToken *)tokenInputView:(CLTokenInputView *)view tokenForText:(NSString *)text
{
    return nil;
}

- (void)tokenInputViewDidEndEditing:(CLTokenInputView *)view
{
    NSLog(@"token input view did end editing: %@", view.allTokens);
}

- (void)tokenInputViewDidBeginEditing:(CLTokenInputView *)view
{
    
    NSLog(@"token input view did begin editing: %@", view);
    //view.accessoryView = [self contactAddButton];
    //    [self.view removeConstraint:self.tableViewTopLayoutConstraint];
    //    self.tableViewTopLayoutConstraint = [NSLayoutConstraint constraintWithItem:self.tableView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:view attribute:NSLayoutAttributeBottom multiplier:1.0 constant:0];
    //    [self.view addConstraint:self.tableViewTopLayoutConstraint];
    //[self.view layoutIfNeeded];
}
@end
